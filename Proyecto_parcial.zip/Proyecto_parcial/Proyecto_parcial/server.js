// -------------------- IMPORTS Y CONFIGURACIÓN INICIAL --------------------
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
// Servir archivos estáticos desde la carpeta actual (index.html está en el mismo directorio que este server.js)
app.use(express.static(path.join(__dirname)));

// -------------------- CONEXIÓN A LA BASE DE DATOS --------------------
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'negocio_db'
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err);
    process.exit(1);
  }
  console.log('✅ Conexión a la base de datos establecida.');
});

// -------------------- MÓDULO LOGIN --------------------
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Complete todos los campos' });
  }

  const sql = 'SELECT id, nombre, usuario, rol FROM usuarios WHERE usuario = ? AND pass = ?';
  db.query(sql, [username, password], (err, rows) => {
    if (err) {
      console.error('Error en /api/login (query):', err);
      return res.status(500).json({ success: false, message: 'Error en el servidor' });
    }

    if (rows.length > 0) {
      return res.json({ success: true, message: 'Login exitoso ✅', user: rows[0] });
    } else {
      return res.json({ success: false, message: 'Usuario o contraseña incorrectos ❌' });
    }
  });
});

// -------------------- MÓDULO REGISTRO DE USUARIOS --------------------
app.post('/api/register', (req, res) => {
  const { nombre, username, password } = req.body;
  if (!nombre || !username || !password) {
    return res.status(400).json({ success: false, message: 'Complete todos los campos' });
  }

  // Verificar si el usuario ya existe
  const checkSql = 'SELECT id FROM usuarios WHERE usuario = ?';
  db.query(checkSql, [username], (err, rows) => {
    if (err) {
      console.error('Error en /api/register (check):', err);
      return res.status(500).json({ success: false, message: 'Error en el servidor' });
    }

    if (rows.length > 0) {
      return res.status(400).json({ success: false, message: 'El usuario ya existe' });
    }

    // Insertar nuevo usuario
    const insertSql = 'INSERT INTO usuarios (nombre, usuario, pass) VALUES (?, ?, ?)';
    db.query(insertSql, [nombre, username, password], (err2, result) => {
      if (err2) {
        console.error('Error en /api/register (insert):', err2);
        return res.status(500).json({ success: false, message: 'Error al crear el usuario' });
      }

      res.json({ success: true, message: 'Usuario creado correctamente ✅', userId: result.insertId });
    });
  });
});

// -------------------- MÓDULO PRODUCTOS --------------------

// Listar productos
app.get('/api/productos', (req, res) => {
  // Permitir filtrar por categoria: /api/productos?categoria=Farmacia
  const filtroCategoria = req.query.categoria;
  let sql = 'SELECT id, nombre, descripcion, precio, stock, categoria FROM productos';
  const params = [];
  if (filtroCategoria) {
    sql += ' WHERE categoria = ?';
    params.push(filtroCategoria);
  }
  sql += ' ORDER BY nombre ASC';

  db.query(sql, params, (err, rows) => {
    if (err) {
      console.error('Error en /api/productos:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener productos' });
    }
    res.json(rows);
  });
});

// Reporte de productos con bajo stock
app.get('/api/productos/bajo-stock', (req, res) => {
  // Permitir recibir un umbral como query param: /api/productos/bajo-stock?umbral=5
  const umbral = parseInt(req.query.umbral, 10) || 10;
  const sql = 'SELECT id, nombre, precio, stock FROM productos WHERE stock < ? ORDER BY stock ASC';

  db.query(sql, [umbral], (err, rows) => {
    if (err) {
      console.error('Error en /api/productos/bajo-stock:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener el reporte de stock' });
    }
    res.json(rows);
  });
});

// Buscar un producto por ID
app.get('/api/productos/:id', (req, res) => {
  const { id } = req.params; // Capturar el ID que viene en la URL

  const sql = 'SELECT nombre, descripcion, precio, stock FROM productos WHERE id = ?';

  db.query(sql, [id], (err, rows) => {
    if (err) {
      console.error('Error en /api/productos/:id:', err);
      return res.status(500).json({ success: false, message: 'Error al buscar el producto' });
    }

    if (rows.length > 0) {
      // Si se encuentra el producto, lo devolvemos
      res.json({ success: true, producto: rows[0] });
    } else {
      // Si no, devolvemos un error 404
      res.status(404).json({ success: false, message: 'Producto no encontrado' });
    }
  });
});

// Agregar producto
app.post('/api/productos', (req, res) => {
  const { nombre, descripcion, precio, stock, categoria } = req.body;
  if (!nombre || precio == null) {
    return res.status(400).json({ success: false, message: 'Faltan datos del producto' });
  }

  const sql = 'INSERT INTO productos (nombre, descripcion, precio, stock, categoria) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [nombre, descripcion || '', parseFloat(precio), parseInt(stock || 0), categoria || 'Sin categoría'], (err, result) => {
    if (err) {
      console.error('Error en /api/productos (insert):', err);
      return res.status(500).json({ success: false, message: 'Error al crear producto' });
    }

    res.json({ success: true, message: 'Producto creado correctamente 🎉', id: result.insertId });
  });
});

// Eliminar producto (ruta a nivel superior)
app.delete('/api/productos/:id', (req, res) => {
  const { id } = req.params;
  if (!id) return res.status(400).json({ success: false, message: 'ID inválido' });

  const sql = 'DELETE FROM productos WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error eliminando producto:', err);
      return res.status(500).json({ success: false, message: 'Error al eliminar producto' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Producto no encontrado' });
    }

    res.json({ success: true, message: 'Producto eliminado correctamente' });
  });
});
// Listar todas las ventas (Historial)
app.get('/api/ventas', (req, res) => {
  // Unimos la tabla de ventas con la de usuarios para obtener el nombre del vendedor
  const sql = `
    SELECT v.id, v.fecha, v.total, u.nombre as usuario_nombre 
    FROM ventas v
    LEFT JOIN usuarios u ON v.usuario_id = u.id
    ORDER BY v.fecha DESC`;

  db.query(sql, (err, rows) => {
    if (err) {
      console.error('Error en GET /api/ventas:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener el historial de ventas' });
    }
    res.json(rows);
  });
});
// -------------------- MÓDULO VENTAS --------------------
app.post('/api/ventas', (req, res) => {
  const { items, usuario_id } = req.body;
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ success: false, message: 'No hay ítems en la venta' });
  }

  let index = 0;
  let total = 0.0;

  function checkNext() {
    if (index >= items.length) {
      const insertVentaSql = 'INSERT INTO ventas (total, usuario_id) VALUES (?, ?)';
      db.query(insertVentaSql, [total, usuario_id || null], (errV, resultV) => {
        if (errV) {
          console.error('Error insertando venta:', errV);
          return res.status(500).json({ success: false, message: 'Error al registrar la venta' });
        }

        const ventaId = resultV.insertId;
        insertDetail(0, ventaId);
      });
      return;
    }

    const it = items[index];
    const sqlProd = 'SELECT id, stock, precio FROM productos WHERE id = ?';
    db.query(sqlProd, [it.producto_id], (errP, rowsP) => {
      if (errP) {
        console.error('Error consultando producto:', errP);
        return res.status(500).json({ success: false, message: 'Error al verificar productos' });
      }

      if (!rowsP || rowsP.length === 0) {
        return res.status(400).json({ success: false, message: `Producto ${it.producto_id} no existe` });
      }

      const stockDisponible = rowsP[0].stock;
      if (stockDisponible < it.cantidad) {
        return res.status(400).json({ success: false, message: `Stock insuficiente para producto ${it.producto_id}` });
      }

      const precioUnit = (it.precio_unitario != null) ? Number(it.precio_unitario) : parseFloat(rowsP[0].precio);
      total += precioUnit * Number(it.cantidad);

      index++;
      checkNext();
    });
  }

  function insertDetail(idx, ventaId) {
    if (idx >= items.length) {
      return res.json({ success: true, message: 'Venta registrada correctamente 🧾', ventaId, total });
    }

    const it = items[idx];
    const insertDetSql = 'INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)';
    db.query(insertDetSql, [ventaId, it.producto_id, it.cantidad, it.precio_unitario], (errD) => {
      if (errD) {
        console.error('Error insertando detalle:', errD);
        return res.status(500).json({ success: false, message: 'Error al registrar detalle de venta' });
      }

      const updateStockSql = 'UPDATE productos SET stock = stock - ? WHERE id = ?';
      db.query(updateStockSql, [it.cantidad, it.producto_id], (errU) => {
        if (errU) {
          console.error('Error actualizando stock:', errU);
          return res.status(500).json({ success: false, message: 'Error al actualizar stock' });
        }

        insertDetail(idx + 1, ventaId);
      });
    });
  }

  checkNext();
});

// -------------------- MÓDULO CAJA --------------------

// Apertura
app.post('/api/caja/apertura', (req, res) => {
  const { apertura, usuario_id } = req.body;
  if (apertura == null) {
    return res.status(400).json({ success: false, message: 'Falta monto de apertura' });
  }

  const sql = 'INSERT INTO caja (fecha, apertura, usuario_id) VALUES (CURDATE(), ?, ?)';
  db.query(sql, [parseFloat(apertura), usuario_id || null], (err, result) => {
    if (err) {
      console.error('Error en /api/caja/apertura:', err);
      return res.status(500).json({ success: false, message: 'Error al abrir caja' });
    }

    res.json({ success: true, message: 'Caja abierta correctamente 💵', cajaId: result.insertId });
  });
});

// Movimiento
app.post('/api/caja/movimiento', (req, res) => {
  const { caja_id, descripcion, monto, tipo } = req.body;
  if (!caja_id || monto == null || !['entrada', 'salida'].includes(tipo)) {
    return res.status(400).json({ success: false, message: 'Datos inválidos' });
  }

  const sql = 'INSERT INTO movimientos_caja (caja_id, descripcion, monto, tipo) VALUES (?, ?, ?, ?)';
  db.query(sql, [caja_id, descripcion || '', parseFloat(monto), tipo], (err, result) => {
    if (err) {
      console.error('Error en /api/caja/movimiento:', err);
      return res.status(500).json({ success: false, message: 'Error al insertar movimiento' });
    }

    res.json({ success: true, message: 'Movimiento registrado ✅', movimientoId: result.insertId });
  });
});

// Cierre
app.post('/api/caja/cierre', (req, res) => {
  const { caja_id, cierre } = req.body;
  if (!caja_id || cierre == null) {
    return res.status(400).json({ success: false, message: 'Faltan datos para cierre' });
  }

  const sqlA = 'SELECT apertura FROM caja WHERE id = ?';
  db.query(sqlA, [caja_id], (errA, rowsA) => {
    if (errA) {
      console.error('Error en /api/caja/cierre (apertura):', errA);
      return res.status(500).json({ success: false, message: 'Error al consultar caja' });
    }

    if (!rowsA || rowsA.length === 0) {
      return res.status(400).json({ success: false, message: 'Caja no encontrada' });
    }

    const apertura = parseFloat(rowsA[0].apertura);

    const sqlMov = 'SELECT tipo, SUM(monto) as total FROM movimientos_caja WHERE caja_id = ? GROUP BY tipo';
    db.query(sqlMov, [caja_id], (errM, rowsM) => {
      if (errM) {
        console.error('Error en /api/caja/cierre (mov):', errM);
        return res.status(500).json({ success: false, message: 'Error al consultar movimientos' });
      }

      let entradas = 0, salidas = 0;
      for (const r of rowsM) {
        if (r.tipo === 'entrada') entradas = parseFloat(r.total);
        if (r.tipo === 'salida') salidas = parseFloat(r.total);
      }

      const esperado = apertura + entradas - salidas;
      const diferencia = parseFloat(cierre) - esperado;

      const updateSql = 'UPDATE caja SET cierre = ? WHERE id = ?';
      db.query(updateSql, [parseFloat(cierre), caja_id], (errU) => {
        if (errU) {
          console.error('Error actualizando cierre:', errU);
          return res.status(500).json({ success: false, message: 'Error al cerrar caja' });
        }

        res.json({ success: true, apertura, entradas, salidas, esperado, cierre: parseFloat(cierre), diferencia });
      });
    });
  });
});

// Listar movimientos
app.get('/api/caja/movimientos', (req, res) => {
  const sql = `SELECT mc.*, c.fecha as caja_fecha
               FROM movimientos_caja mc
               LEFT JOIN caja c ON mc.caja_id = c.id
               ORDER BY mc.fecha DESC`;

  db.query(sql, (err, rows) => {
    if (err) {
      console.error('Error en /api/caja/movimientos:', err);
      return res.status(500).json({ success: false, message: 'Error al listar movimientos' });
    }

    res.json(rows);
  });
});

// -------------------- INICIO DEL SERVIDOR --------------------
app.listen(port, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${port}`);
});
