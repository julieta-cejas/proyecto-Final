// Ejecutar cuando el DOM esté listo para evitar errores por elementos faltantes
function init() {
  // -------------------- 1. CONSTANTES GLOBALES Y ESTADO --------------------
  const API_URL = "http://localhost:3000/api";
  let carrito = []; // Estado del carrito de compras
  let productosCache = []; // Cache local de productos para búsquedas por nombre

  // --- Autocompletar datos del producto en Ventas ---
  const ventaProdIdInput = document.getElementById('ventaProdId');
  const ventaProdNombreInput = document.getElementById('ventaProdNombre');
  const ventaPrecioInput = document.getElementById('ventaPrecio');
  const ventaMsgP = document.getElementById('ventaMsg'); // Párrafo para mensajes

  if (ventaProdIdInput) {
    ventaProdIdInput.addEventListener('change', async () => {
      const productoId = ventaProdIdInput.value;

      // Si se borra el ID, limpiar los campos
      if (!productoId) {
        if (ventaProdNombreInput) ventaProdNombreInput.value = '';
        if (ventaPrecioInput) ventaPrecioInput.value = '';
        if (ventaMsgP) ventaMsgP.textContent = '';
        return;
      }

      try {
        const res = await fetch(`${API_URL}/productos/${productoId}`);
        const data = await res.json();

        if (data.success) {
          const { producto } = data;
          if (ventaProdNombreInput) ventaProdNombreInput.value = producto.nombre;
          if (ventaPrecioInput) ventaPrecioInput.value = producto.precio;
          if (ventaMsgP) ventaMsgP.textContent = ''; // Limpiar cualquier mensaje de error anterior
        } else {
          if (ventaProdNombreInput) ventaProdNombreInput.value = ''; // Si el producto no se encuentra (error 404) o hay otro error
          if (ventaPrecioInput) ventaPrecioInput.value = '';
          if (ventaMsgP) ventaMsgP.textContent = data.message; // Mostramos "Producto no encontrado"
        }
      } catch (error) {
        console.error('Error al buscar producto:', error);
        if (ventaProdNombreInput) ventaProdNombreInput.value = '';
        if (ventaPrecioInput) ventaPrecioInput.value = '';
        if (ventaMsgP) ventaMsgP.textContent = 'Error de conexión. No se pudo buscar el producto.';
      }
    });
  }

// -------------------- 2. REFERENCIAS A ELEMENTOS DEL DOM --------------------
// Modales
const loginModal = document.getElementById("loginModal");
const sessionModal = document.getElementById("sessionModal");
const productosModal = document.getElementById('productosModal');
const filtroCategoria = document.getElementById('filtrocategoria');
const ventasModal = document.getElementById('ventasModal');
const cajaModal = document.getElementById('cajaModal');
const historialModal = document.getElementById('historialModal');
const reporteStockModal = document.getElementById('reporteStockModal');
const movimientosModal = document.getElementById('movimientosModal');

// Secciones
const homeSection = document.getElementById('homeSection');

// Formularios
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

// Botones Menú Principal
const btnHomeProductos = document.getElementById('btnHomeProductos');
const btnHomeVentas = document.getElementById('btnHomeVentas');
const btnHomeCaja = document.getElementById('btnHomeCaja');
const btnHomeHistorial = document.getElementById('btnHomeHistorial');
const btnHomeReporteStock = document.getElementById('btnHomeReporteStock');
const btnHomeMovimientos = document.getElementById('btnHomeMovimientos');

// Botones de Modales (Login/Registro/Sesión)
const showRegisterBtn = document.getElementById("showRegisterBtn");
const showLogin = document.getElementById("showLogin");
const btnRegister = document.getElementById("btnRegister");
const btnLogin = document.getElementById("btnLogin");
const btnLogout = document.getElementById("btnLogout");
const btnCloseSessionModal = document.getElementById("btnCloseSessionModal");

// Botones de Cierre (X) y Cancelar
const closeProductos = productosModal.querySelector('.close-button');
const cancelProductos = productosModal.querySelector('.btn-cancel');
const closeVentas = ventasModal.querySelector('.close-button');
const cancelVentas = ventasModal.querySelector('.btn-cancel');
const closeCaja = cajaModal.querySelector('.close-button');
const closeHistorial = historialModal.querySelector('.close-button');
const closeReporteStock = reporteStockModal.querySelector('.close-button');
const closeMovimientos = movimientosModal.querySelector('.close-button');
const closeSession = sessionModal.querySelector('.close-button');

// Otros Elementos
const modalTitle = document.getElementById("modalTitle");

// -------------------- 3. DEFINICIÓN DE FUNCIONES --------------------

// --- Funciones de Módulos ---
async function cargarProductos() {
  // Aplicar filtro por categoría si el usuario lo seleccionó
  const filtro = (document.getElementById('filtroCategoria') && document.getElementById('filtroCategoria').value) || '';
  const q = filtro ? `?categoria=${encodeURIComponent(filtro)}` : '';
  const res = await fetch(`${API_URL}/productos${q}`);
  const data = await res.json();
  // Actualizar cache local (si el resultado es un subconjunto por filtro, mantenemos también la cache completa mediante actualizarCacheProductos)
  productosCache = Array.isArray(data) ? data : [];
  const tbody = document.querySelector("#tablaProductos tbody");
  tbody.innerHTML = "";
  data.forEach(p => {
    const tr = document.createElement("tr");
    const categoriaText = p.categoria || p.categoria_nombre || '';
    tr.innerHTML = `<td>${p.id}</td><td>${p.nombre}</td><td title="${(p.descripcion||'').replace(/"/g,'&quot;')}">${p.descripcion || ''}</td><td>${categoriaText}</td><td>${p.precio}</td><td>${p.stock}</td>`;
    // Crear celda de acciones con botón Eliminar
    const accionesTd = document.createElement('td');
    // Botón Seleccionar: rellena el formulario de ventas
    const btnSeleccionar = document.createElement('button');
    btnSeleccionar.textContent = 'Seleccionar';
    btnSeleccionar.className = 'btn-seleccionar-prod';
    btnSeleccionar.dataset.productoId = p.id;
    btnSeleccionar.dataset.productoNombre = p.nombre;
    btnSeleccionar.dataset.productoPrecio = p.precio;
    accionesTd.appendChild(btnSeleccionar);
    // Separador visual
    const sep = document.createTextNode(' ');
    accionesTd.appendChild(sep);
    const btnEliminar = document.createElement('button');
    btnEliminar.textContent = 'Eliminar';
    btnEliminar.className = 'btn-eliminar-prod';
    btnEliminar.dataset.productoId = p.id;
    accionesTd.appendChild(btnEliminar);
    tr.appendChild(accionesTd);
    tbody.appendChild(tr);
  });
}

// Obtener y actualizar cache de productos (puede llamarse al iniciar)
async function actualizarCacheProductos() {
  try {
    const res = await fetch(`${API_URL}/productos`);
    const data = await res.json();
    productosCache = Array.isArray(data) ? data : [];
    // Poblar selects de categorías en la UI
    try { poblarCategoriasUI(); } catch (e) { /* ignore if UI not ready */ }
  } catch (err) {
    console.error('No se pudo actualizar cache de productos:', err);
    productosCache = [];
  }
}

// Rellena los selectores de categoría (prodCategoria y filtroCategoria)
function poblarCategoriasUI() {
  const selProd = document.getElementById('prodCategoria');
  const selFiltro = document.getElementById('filtroCategoria');
  if (!selProd && !selFiltro) return;

  // Obtener categorías únicas desde la cache de productos
  const categorias = Array.from(new Set(productosCache.map(p => (p.categoria || p.categoria_nombre || 'Sin categoría')))).filter(Boolean);

  // Helper para rellenar un select conservando selección
  function fill(selectEl, includeAll) {
    if (!selectEl) return;
    const prev = selectEl.value;
    selectEl.innerHTML = '';
    if (includeAll) selectEl.appendChild(new Option('Todas las categorías', ''));
    categorias.forEach(cat => selectEl.appendChild(new Option(cat, cat)));
    if (prev) selectEl.value = prev;
  }

  fill(selProd, false);
  fill(selFiltro, true);
}

// Debounce util
function debounce(fn, wait) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), wait);
  };
}

// Buscar producto por nombre en cache y rellenar campos
const buscarPorNombre = debounce(() => {
  const texto = (ventaProdNombreInput.value || '').trim().toLowerCase();
  const msgEl = document.getElementById('ventaMsg');
  if (!texto) {
    ventaProdIdInput.value = '';
    ventaPrecioInput.value = '';
    if (msgEl) msgEl.textContent = '';
    return;
  }

  // Filtrar productos que contengan el texto en el nombre (case-insensitive)
  const matches = productosCache.filter(p => (p.nombre || '').toLowerCase().includes(texto));

  if (matches.length === 1) {
    const p = matches[0];
    ventaProdIdInput.value = p.id;
    ventaPrecioInput.value = p.precio;
    if (msgEl) msgEl.textContent = '';
  } else if (matches.length === 0) {
    ventaProdIdInput.value = '';
    ventaPrecioInput.value = '';
    if (msgEl) msgEl.textContent = 'No se encontró ningún producto con ese nombre.';
  } else {
    // Muchas coincidencias: no auto-seleccionar, informar al usuario
    ventaProdIdInput.value = '';
    ventaPrecioInput.value = '';
    if (msgEl) msgEl.textContent = `Se encontraron ${matches.length} coincidencias. Escribe más para filtrar.`;
  }
}, 400);

ventaProdNombreInput.addEventListener('input', buscarPorNombre);

async function cargarHistorialVentas() {
  const tbody = document.getElementById("historialTablaBody");
  tbody.innerHTML = '<tr><td colspan="4">Cargando historial...</td></tr>';
  try {
    const res = await fetch(`${API_URL}/ventas`);
    const ventas = await res.json();
    tbody.innerHTML = "";
    if (ventas.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4">No se encontraron ventas.</td></tr>';
      return;
    }
    ventas.forEach(venta => {
      const tr = document.createElement("tr");
      const fecha = new Date(venta.fecha).toLocaleString();
      tr.innerHTML = `<td>${venta.id}</td><td>${fecha}</td><td>$${venta.total}</td><td>${venta.usuario_nombre || 'No asignado'}</td>`;
      tbody.appendChild(tr);
    });
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="4">Error al cargar el historial.</td></tr>';
    console.error("Error al obtener historial de ventas:", error);
  }
}

// Cargar reporte de stock. Acepta un parámetro opcional 'umbral' (number)
async function cargarReporteStock(umbral = 10) {
  const tbody = document.getElementById("reporteStockTablaBody");
  if (!tbody) return;
  tbody.innerHTML = '<tr><td colspan="4">Cargando reporte...</td></tr>';
  try {
    const query = umbral ? `?umbral=${encodeURIComponent(Number(umbral))}` : '';
    const res = await fetch(`${API_URL}/productos/bajo-stock${query}`);
    const productos = await res.json();
    // Si la API devuelve { success: false, message: ... } manejarlo
    if (!Array.isArray(productos)) {
      tbody.innerHTML = `<tr><td colspan="4">${productos.message || 'No hay datos'}</td></tr>`;
      return;
    }
    tbody.innerHTML = "";
    if (productos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="4">No hay productos con bajo stock.</td></tr>';
      return;
    }
    productos.forEach(producto => {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${producto.id}</td><td>${producto.nombre}</td><td>$${producto.precio}</td><td>${producto.stock}</td>`;
      tbody.appendChild(tr);
    });
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="4">Error al cargar el reporte.</td></tr>';
    console.error("Error al obtener reporte de stock:", error);
  }
}

async function cargarMovimientosCaja() {
  const tbody = document.getElementById("movimientosTablaBody");
  tbody.innerHTML = '<tr><td colspan="5">Cargando movimientos...</td></tr>';

  try {
    const res = await fetch(`${API_URL}/caja/movimientos`);
    const movimientos = await res.json();
    
    tbody.innerHTML = "";

    if (movimientos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5">No hay movimientos registrados.</td></tr>';
      return;
    }

    movimientos.forEach(mov => {
      const tr = document.createElement("tr");
      const fecha = new Date(mov.fecha).toLocaleString();
      const tipoClase = mov.tipo === 'entrada' ? 'monto-entrada' : 'monto-salida';
      
      tr.innerHTML = `
        <td>${mov.id}</td>
        <td>${fecha}</td>
        <td>${mov.descripcion || '-'}</td>
        <td>${mov.tipo}</td>
        <td class="${tipoClase}">$${mov.monto}</td> 
      `;
      tbody.appendChild(tr);
    });
  } catch (error) {
    tbody.innerHTML = '<tr><td colspan="5">Error al cargar los movimientos.</td></tr>';
    console.error("Error al obtener los movimientos de caja:", error);
  }
}

function renderCarrito() {
  const tbody = document.getElementById("carrito-body");
  tbody.innerHTML = ""; // Limpiar el contenido anterior de la tabla

  if (carrito.length === 0) {
    tbody.innerHTML = '<tr><td colspan="4">El carrito está vacío.</td></tr>';
    return;
  }

  carrito.forEach(item => {
    const tr = document.createElement("tr");
    const subtotal = item.cantidad * item.precio_unitario;

    tr.innerHTML = `
      <td>${item.nombre}</td>
      <td>${item.cantidad}</td>
      <td>$${item.precio_unitario.toFixed(2)}</td>
      <td>$${subtotal.toFixed(2)}</td>
    `;
    tbody.appendChild(tr);
  });
}

// --- Funciones de Utilidad ---
function habilitarEnter(inputIds, buttonId) {
  const boton = document.getElementById(buttonId);
  inputIds.forEach(id => {
    const input = document.getElementById(id);
    input.addEventListener('keydown', (evento) => {
      if (evento.key === 'Enter') {
        evento.preventDefault();
        boton.click();
      }
    });
  });
}

// --- Función para actualizar el botón de Login/Usuario ---
function actualizarBotonLogin() {
  const btnLoginView = document.getElementById('btnLoginView');
  const usuario = localStorage.getItem('usuario');
  // Mostrar siempre la misma etiqueta en el botón del header (sin saludo con nombre)
  btnLoginView.textContent = 'CERRAR';
}

// Nota: El soporte de modo oscuro fue removido. Antes existía applyTheme() aquí.
// -------------------- 4. ASIGNACIÓN DE EVENTOS (EVENT LISTENERS) --------------------

// --- Eventos de Login y Registro ---
if (showRegisterBtn) {
  showRegisterBtn.addEventListener("click", (e) => {
    e.preventDefault();
    if (modalTitle) modalTitle.textContent = "Crear nueva cuenta";
    if (loginForm) loginForm.classList.add("hidden");
    if (registerForm) registerForm.classList.remove("hidden");
  });
}

if (showLogin) {
  showLogin.addEventListener("click", (e) => {
    e.preventDefault();
    if (modalTitle) modalTitle.textContent = "Iniciar sesión";
    if (registerForm) registerForm.classList.add("hidden");
    if (loginForm) loginForm.classList.remove("hidden");
  });
}

if (btnRegister) {
  btnRegister.addEventListener("click", async () => {
    const nombre = document.getElementById("regName").value;
    const username = document.getElementById("regUser").value;
    const password = document.getElementById("regPass").value;
    const messageEl = document.getElementById("registerMsg");
    const res = await fetch(`${API_URL}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre, username, password }),
    });
    const data = await res.json();
    messageEl.textContent = data.message;
    if (data.success) {
        setTimeout(() => {
            showLogin.click();
            messageEl.textContent = "";
        }, 2000);
    }
  });
}

if (btnLogin) {
  btnLogin.addEventListener("click", async () => {
    const username = document.getElementById("loginUser") ? document.getElementById("loginUser").value : '';
    const password = document.getElementById("loginPass") ? document.getElementById("loginPass").value : '';
    try {
      const res = await fetch(`${API_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      const loginMsgEl = document.getElementById("loginMsg");
      if (loginMsgEl) loginMsgEl.textContent = data.message;
      if (data.success) {
        if (loginModal) loginModal.classList.add("hidden");
        if (homeSection) homeSection.classList.remove('hidden');
        localStorage.setItem("usuario", JSON.stringify(data.user));
        await cargarProductos();
        actualizarBotonLogin();
      }
    } catch (err) {
      console.error('Error en login:', err);
      const loginMsgEl = document.getElementById("loginMsg");
      if (loginMsgEl) loginMsgEl.textContent = 'Error de conexión';
    }
  });
}
  // --- Eventos de Sesión ---
  // Solo dejamos el comportamiento de cierre del modal (X y clic fuera):
  if (closeSession) {
    closeSession.addEventListener('click', () => {
      if (sessionModal) sessionModal.classList.add('hidden');
      if (homeSection) homeSection.classList.remove('hidden');
    });
  }

  if (sessionModal) {
    sessionModal.addEventListener("click", (evento) => {
      if (evento.target.id === "sessionModal") {
        sessionModal.classList.add("hidden");
        if (homeSection) homeSection.classList.remove('hidden');
      }
    });
  }

  const btnLoginViewEl = document.getElementById("btnLoginView");
  if (btnLoginViewEl) {
    btnLoginViewEl.addEventListener("click", () => {
      const usuario = localStorage.getItem("usuario");
      if (usuario) {
        const sessionUserMsg = document.getElementById("sessionUserMsg");
        if (sessionUserMsg) sessionUserMsg.textContent = `Sesión Iniciada`;
        if (sessionModal) sessionModal.classList.remove("hidden");
        if (homeSection) homeSection.classList.add('hidden');
      } else {
        if (loginModal) loginModal.classList.remove("hidden");
      }
    });
  }

// --- Logout desde el modal de sesión ---
const btnLogoutModal = document.getElementById('btnLogout');
if (btnLogoutModal) {
  btnLogoutModal.addEventListener('click', () => {
    // Eliminar usuario y regresar a pantalla de login
    localStorage.removeItem('usuario');
    actualizarBotonLogin();
    sessionModal.classList.add('hidden');
    homeSection.classList.add('hidden');
    loginModal.classList.remove('hidden');
  });
}

// --- Eventos de Modales Principales (Abrir/Cerrar) ---
btnHomeProductos.addEventListener('click', () => {
  // Al abrir el modal de Productos, mostrar el formulario de registro (por defecto)
  productosModal.classList.remove('hidden');
  homeSection.classList.add('hidden');
  const cont = document.getElementById('productosTablaContainer');
  const btn = document.getElementById('btnVerListaProductos');
  const formBox = productosModal.querySelector('.form-box');
  // Ocultar la tabla y mostrar el botón, pero mantener el formulario visible para agregar productos
  if (cont) cont.classList.add('hidden');
  if (btn) btn.classList.remove('hidden');
  if (formBox) formBox.classList.remove('hidden');
});


btnHomeVentas.addEventListener('click', () => { ventasModal.classList.remove('hidden'); homeSection.classList.add('hidden'); });
closeVentas.addEventListener('click', () => { ventasModal.classList.add('hidden'); homeSection.classList.remove('hidden'); });
if (cancelVentas) {
  cancelVentas.addEventListener('click', () => {
    // Vaciar el carrito y limpiar los campos para iniciar una nueva venta desde cero
    carrito = [];
    renderCarrito();

    // Limpiar inputs relacionados a la venta
    const ventaProdId = document.getElementById("ventaProdId");
    const ventaProdNombre = document.getElementById("ventaProdNombre");
    const ventaCant = document.getElementById("ventaCant");
    const ventaPrecio = document.getElementById("ventaPrecio");
    const ventaMsg = document.getElementById("ventaMsg");

    if (ventaProdId) ventaProdId.value = '';
    if (ventaProdNombre) ventaProdNombre.value = '';
    if (ventaCant) ventaCant.value = '';
    if (ventaPrecio) ventaPrecio.value = '';
    if (ventaMsg) ventaMsg.textContent = '';

    ventasModal.classList.add('hidden');
    homeSection.classList.remove('hidden');
  });
}

btnHomeCaja.addEventListener('click', () => { cajaModal.classList.remove('hidden'); homeSection.classList.add('hidden'); });
closeCaja.addEventListener('click', () => { cajaModal.classList.add('hidden'); homeSection.classList.remove('hidden'); });

btnHomeHistorial.addEventListener('click', () => {
  historialModal.classList.remove('hidden');
  cargarHistorialVentas();
  homeSection.classList.add('hidden');
});
closeHistorial.addEventListener('click', () => { historialModal.classList.add('hidden'); homeSection.classList.remove('hidden'); });

btnHomeReporteStock.addEventListener('click', () => {
  reporteStockModal.classList.remove('hidden');
  // Al abrir, no cargar automáticamente; mostramos input para umbral y dejamos al usuario decidir
  homeSection.classList.add('hidden');
});
closeReporteStock.addEventListener('click', () => { reporteStockModal.classList.add('hidden'); homeSection.classList.remove('hidden'); });


// Botón para ver/recargar la lista de productos dentro del modal
const btnVerListaProductos = document.getElementById('btnVerListaProductos');
if (btnVerListaProductos) {
  btnVerListaProductos.addEventListener('click', () => {
    const cont = document.getElementById('productosTablaContainer');
    // Mostrar la tabla y ocultar el botón
    if (cont) cont.classList.remove('hidden');
      btnVerListaProductos.classList.add('hidden');
      // Ocultar el formulario de registro de producto cuando se muestra la lista
      const formBox = productosModal.querySelector('.form-box');
            if (formBox) formBox.classList.add('hidden');
    // Marcar modal como en modo lista (CSS adicional ocultará el form-box si algo falla)
    const modalContent = productosModal.querySelector('.modal-content');
    if (modalContent) modalContent.classList.add('list-visible');
      // Cargar productos en la tabla
      cargarProductos();
    // opcional: mover el foco a la tabla
    setTimeout(() => {
      const tabla = document.getElementById('tablaProductos');
      if (tabla) tabla.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  });
}

// Filtrar al cambiar el selector de categoría
const filtroSel = document.getElementById('filtroCategoria');
if (filtroSel) {
  filtroSel.addEventListener('change', () => cargarProductos());
}

// Manejo de cierre/cancelar del modal de Productos: resetear vista (mostrar formulario, ocultar tabla)
if (closeProductos) {
  closeProductos.addEventListener('click', () => {
    productosModal.classList.add('hidden');
    homeSection.classList.remove('hidden');
    const cont = document.getElementById('productosTablaContainer');
    const btn = document.getElementById('btnVerListaProductos');
    const formBox = productosModal.querySelector('.form-box');
    if (cont) cont.classList.add('hidden');
    if (btn) btn.classList.remove('hidden');
  if (formBox) formBox.classList.remove('hidden');
  // Quitar modo lista si estaba activo
  const modalContent = productosModal.querySelector('.modal-content');
  if (modalContent) modalContent.classList.remove('list-visible');
  });
}
if (cancelProductos) {
  cancelProductos.addEventListener('click', () => {
    productosModal.classList.add('hidden');
    homeSection.classList.remove('hidden');
    const cont = document.getElementById('productosTablaContainer');
    const btn = document.getElementById('btnVerListaProductos');
    const formBox = productosModal.querySelector('.form-box');
    if (cont) cont.classList.add('hidden');
    if (btn) btn.classList.remove('hidden');
    if (formBox) formBox.classList.remove('hidden');
  });
}

// Evento para el botón 'Cargar Reporte' dentro del modal de Reporte de Stock
const btnCargarReporteStock = document.getElementById('btnCargarReporteStock');
if (btnCargarReporteStock) {
  btnCargarReporteStock.addEventListener('click', () => {
    const umbralInput = document.getElementById('stockThreshold');
    const umbral = umbralInput && umbralInput.value ? Number(umbralInput.value) : 10;
    cargarReporteStock(umbral);
  });
}

// Cerrar/Cancelar del modal de reporte de stock (si hay botones cancel)
const closeReporteStockBtn = closeReporteStock; // ya referenciado arriba
const reporteCancelBtns = document.querySelectorAll('#reporteStockModal .btn-cancel');
reporteCancelBtns.forEach(b => b.addEventListener('click', () => {
  reporteStockModal.classList.add('hidden');
  homeSection.classList.remove('hidden');
}));

// --- Eventos del Módulo Ventas ---
const btnAgregarItemEl = document.getElementById("btnAgregarItem");
if (btnAgregarItemEl) {
  btnAgregarItemEl.addEventListener("click", () => {
    let producto_id = Number(document.getElementById("ventaProdId").value || 0);
    const nombre = document.getElementById("ventaProdNombre").value || ''; // <-- Obtenemos el nombre
    const cantidad = Number(document.getElementById("ventaCant").value || 0);
    const precio_unitario = Number(document.getElementById("ventaPrecio").value || 0);
    
    // Si no hay ID, intentar resolver por nombre usando la cache (coincidencia exacta o primera coincidencia)
    if (!producto_id && nombre) {
      const found = productosCache.find(p => (p.nombre || '').toLowerCase() === nombre.trim().toLowerCase()) || productosCache.find(p => (p.nombre || '').toLowerCase().includes(nombre.trim().toLowerCase()));
      if (found) {
        producto_id = found.id;
        // Si el precio está vacío, rellenar con el del producto
        if (!precio_unitario) {
          const ventaPrecioEl = document.getElementById("ventaPrecio");
          if (ventaPrecioEl) ventaPrecioEl.value = found.precio;
        }
      }
    }

    const precio_unitario_final = Number(document.getElementById("ventaPrecio").value || 0);
    if (!producto_id || !nombre || !cantidad || !precio_unitario_final) {
      return alert("Primero busca un producto y especifica la cantidad.");
    }

    // Ahora guardamos también el nombre en el objeto del carrito
    carrito.push({ producto_id, nombre, cantidad, precio_unitario: precio_unitario_final });
    renderCarrito();

    // Limpiamos los campos para el siguiente ítem
    const ventaProdIdEl = document.getElementById("ventaProdId");
    const ventaProdNombreEl = document.getElementById("ventaProdNombre");
    const ventaCantEl = document.getElementById("ventaCant");
    const ventaPrecioEl = document.getElementById("ventaPrecio");
    if (ventaProdIdEl) ventaProdIdEl.value = '';
    if (ventaProdNombreEl) ventaProdNombreEl.value = '';
    if (ventaCantEl) ventaCantEl.value = '';
    if (ventaPrecioEl) ventaPrecioEl.value = '';
  });
}

// --- Eventos del Módulo Productos (Agregar nuevo producto) ---
const btnAddProdEl = document.getElementById('btnAddProd');
if (btnAddProdEl) {
  btnAddProdEl.addEventListener('click', async () => {
    const nombreEl = document.getElementById('prodNombre');
    const descEl = document.getElementById('prodDesc');
    const precioEl = document.getElementById('prodPrecio');
    const stockEl = document.getElementById('prodStock');

    const nombre = nombreEl ? nombreEl.value.trim() : '';
    const descripcion = descEl ? descEl.value.trim() : '';
    const precio = precioEl ? precioEl.value.trim() : '';
    const stock = stockEl ? stockEl.value.trim() : '';

    if (!nombre) return alert('Ingrese el nombre del producto.');
    const precioNum = Number(precio);
    if (!precio || isNaN(precioNum)) return alert('Ingrese un precio válido.');
    const stockNum = stock === '' ? 0 : parseInt(stock, 10);

      const categoriaEl = document.getElementById('prodCategoria');
      const categoria = categoriaEl ? categoriaEl.value : '';
      try {
        const res = await fetch(`${API_URL}/productos`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nombre, descripcion, precio: precioNum, stock: stockNum, categoria })
        });
      const data = await res.json();
      alert(data.message || (data.success ? 'Producto agregado' : 'No se pudo agregar'));
      if (data.success) {
        if (nombreEl) nombreEl.value = '';
        if (descEl) descEl.value = '';
        if (precioEl) precioEl.value = '';
          if (stockEl) stockEl.value = '';
          if (categoriaEl) categoriaEl.value = '';
          // Refrescar lista y caché
          await actualizarCacheProductos();
          cargarProductos();
      }
    } catch (err) {
      console.error('Error agregando producto:', err);
      alert('Error de conexión. No se pudo agregar el producto.');
    }
  });
}

const btnFinalizarVentaEl = document.getElementById("btnFinalizarVenta");
if (btnFinalizarVentaEl) {
  btnFinalizarVentaEl.addEventListener("click", async () => {
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    const usuario_id = usuario ? usuario.id : null;
    try {
      const res = await fetch(`${API_URL}/ventas`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: carrito, usuario_id })
      });
      const data = await res.json();
      const ventaMsgEl = document.getElementById("ventaMsg");
      if (ventaMsgEl) ventaMsgEl.textContent = data.message;
      if (data.success) {
        carrito = [];
        renderCarrito();
        cargarProductos();
      }
    } catch (err) {
      console.error('Error finalizando venta:', err);
      const ventaMsgEl = document.getElementById("ventaMsg");
      if (ventaMsgEl) ventaMsgEl.textContent = 'Error de conexión';
    }
  });
}

// --- Eventos del Módulo Caja ---
const btnAbrirCajaEl = document.getElementById("btnAbrirCaja");
if (btnAbrirCajaEl) {
  btnAbrirCajaEl.addEventListener("click", async () => {
    const apertura = document.getElementById("montoApertura") ? document.getElementById("montoApertura").value : '';
    const usuario = JSON.parse(localStorage.getItem("usuario"));
    const usuario_id = usuario ? usuario.id : null;
    try {
      const res = await fetch(`${API_URL}/caja/apertura`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ apertura, usuario_id })
      });
      const data = await res.json();
      const cajaMsgEl = document.getElementById("cajaMsg");
      if (cajaMsgEl) cajaMsgEl.textContent = data.message;
    } catch (err) {
      console.error('Error abriendo caja:', err);
      const cajaMsgEl = document.getElementById("cajaMsg");
      if (cajaMsgEl) cajaMsgEl.textContent = 'Error de conexión';
    }
  });
}

const btnRegistrarMovEl = document.getElementById("btnRegistrarMov");
if (btnRegistrarMovEl) {
  btnRegistrarMovEl.addEventListener("click", async () => {
    const caja_id = document.getElementById("cajaIdMov") ? document.getElementById("cajaIdMov").value : '';
    const descripcion = document.getElementById("descMovimiento") ? document.getElementById("descMovimiento").value : '';
    const monto = document.getElementById("montoMovimiento") ? document.getElementById("montoMovimiento").value : '';
    const tipo = document.getElementById("tipoMovimiento") ? document.getElementById("tipoMovimiento").value : '';
    try {
      const res = await fetch(`${API_URL}/caja/movimiento`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ caja_id, descripcion, monto, tipo })
      });
      const data = await res.json();
      const cajaMsgEl = document.getElementById("cajaMsg");
      if (cajaMsgEl) cajaMsgEl.textContent = data.message;
    } catch (err) {
      console.error('Error registrando movimiento:', err);
      const cajaMsgEl = document.getElementById("cajaMsg");
      if (cajaMsgEl) cajaMsgEl.textContent = 'Error de conexión';
    }
  });
}

const btnCerrarCajaEl = document.getElementById("btnCerrarCaja");
if (btnCerrarCajaEl) {
  btnCerrarCajaEl.addEventListener("click", async () => {
    const caja_id = document.getElementById("cajaIdCierre") ? document.getElementById("cajaIdCierre").value : '';
    const cierre = document.getElementById("montoCierre") ? document.getElementById("montoCierre").value : '';
    try {
      const res = await fetch(`${API_URL}/caja/cierre`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ caja_id, cierre })
      });
      const data = await res.json();
      const cajaMsgEl = document.getElementById("cajaMsg");
      if (cajaMsgEl) cajaMsgEl.textContent = `Cierre: ${data.message || "OK"} (Dif: ${data.diferencia || 0})`;
    } catch (err) {
      console.error('Error cerrando caja:', err);
      const cajaMsgEl = document.getElementById("cajaMsg");
      if (cajaMsgEl) cajaMsgEl.textContent = 'Error de conexión';
    }
  });
}

// --- Eventos de Movimientos de Caja --- //
btnHomeMovimientos.addEventListener('click', () => {
  movimientosModal.classList.remove('hidden');
  cargarMovimientosCaja();
  homeSection.classList.add('hidden');
});
closeMovimientos.addEventListener('click', () => {
  movimientosModal.classList.add('hidden');
  homeSection.classList.remove('hidden');
});

// El control de tema fue eliminado del HTML/JS. No queda código relacionado al modo oscuro.

// --- Listener para botones Eliminar en la tabla de productos (delegación simple) ---
document.addEventListener('click', async (e) => {
  const btn = e.target.closest && e.target.closest('.btn-eliminar-prod');
  if (!btn) return;

  const productoId = btn.dataset.productoId;
  if (!productoId) return;

  const confirmado = confirm('¿Seguro que quieres eliminar este producto?');
  if (!confirmado) return;

  try {
    const res = await fetch(`${API_URL}/productos/${productoId}`, { method: 'DELETE' });
    const data = await res.json();
    if (data.success) {
      alert(data.message || 'Producto eliminado');
      cargarProductos();
    } else {
      alert(data.message || 'No se pudo eliminar el producto');
    }
  } catch (error) {
    console.error('Error al eliminar producto:', error);
    alert('Error de conexión. No se pudo eliminar el producto.');
  }
});

// Listener para seleccionar un producto desde la lista y rellenar el formulario de Ventas
document.addEventListener('click', (e) => {
  const sel = e.target.closest && e.target.closest('.btn-seleccionar-prod');
  if (!sel) return;

  const productoId = sel.dataset.productoId;
  const productoNombre = sel.dataset.productoNombre;
  const productoPrecio = sel.dataset.productoPrecio;

  // Rellenar inputs del formulario de Ventas
  if (ventaProdIdInput) ventaProdIdInput.value = productoId || '';
  if (ventaProdNombreInput) ventaProdNombreInput.value = productoNombre || '';
  if (ventaPrecioInput) ventaPrecioInput.value = productoPrecio || '';

  // Abrir modal de Ventas y cerrar Productos
  productosModal.classList.add('hidden');
  ventasModal.classList.remove('hidden');
  homeSection.classList.add('hidden');
});

// -------------------- 5. INICIALIZACIÓN --------------------
  habilitarEnter(['loginUser', 'loginPass'], 'btnLogin');
  habilitarEnter(['regName', 'regUser', 'regPass'], 'btnRegister');
  actualizarBotonLogin();
  // Cargar cache de productos al iniciar (útil para búsqueda por nombre)
  actualizarCacheProductos();
}

// Ejecutar init cuando el DOM esté listo (seguro si el script se carga antes o después)
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}