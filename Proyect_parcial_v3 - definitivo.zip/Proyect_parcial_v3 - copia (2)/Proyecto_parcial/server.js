// -------------------- IMPORTS Y CONFIGURACIÓN INICIAL --------------------
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const bcrypt = require('bcryptjs');
const nodemailer = require('nodemailer');
const crypto = require('crypto');

const app = express();
const port = 3000;

const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',   //O el host SMTP que uses
  port: 587,
  secure: false,
  service: 'gmail', // Usando el servicio de Gmail
  auth: {
    user: 'testfinalexam4@gmail.com',  
    pass: 'iasp fiqw blct onid' // contraseña de aplicacion (contraseña normal: Test-9631 )
  }
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
// Servir archivos estáticos desde la carpeta actual (index.html está en el mismo directorio que este server.js)
app.use(express.static(path.join(__dirname)));

// -------------------- CONEXIÓN A LA BASE DE DATOS --------------------
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', 
  password: '',
  database: 'negocio_db1'
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err);
    process.exit(1);
  }
  console.log('✅ Conexión a la base de datos establecida.');
});

// -------------------- EMAIL --------------------

// ENPOINT 1: recibir correo y generar token
app.post('/api/forgot-password', async (req, res) => {
  const { email } = req.body;
  if (!email) return res.json({ success: false, message: 'Email requerido' });

  try{
    //verifica email en BD
    const [rows] = await db.promise().query('SELECT id FROM usuarios WHERE email = ?', [email]);
    if (rows.length === 0) {
      //por seguridad devuelve true para no dar pistas de que correos existen.
      return res.json({ success: true, message: 'Si el correo existe, recibira un enlace' });
    }
    //token unico y expira en 1 hora
    const token = crypto.randomBytes(32).toString('hex');
    const expires = new Date(Date.now() + 3600000); // 1 hora
    
    //almacena el token en la BD
    await db.promise().query('INSERT INTO password_resets (email, token, expires) VALUES (?, ?, ?)', [email, token, expires]);

    //envia correo
    const resetLink = `http://localhost:3000/reset-password?token=${token}`;
    const mailOptions = {
      from: 'testfinalexam4@gmail.com',
      to: email,
      subject: 'Recuperación de contraseña',
      text: `Haz clic en este enlace para resetear tu contraseña: ${resetLink}`
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error("Error de Nodemailes:",error);
        return res.status(500).json({ success: false, message: 'Error al enviar el correo' });
      }
      res.json({ success: true, message: 'Enlace enviado a tu correo' });
    });
  } catch (err) {
    console.error('Error en servidor:', err);
    res.status(500).json({ success: false, message: 'Error interno del servidor' });
  }
});

//ENPOINT 2: valida el token al hacer click en el correo.
app.get('/reset-password', async (req, res) => {
  const { token } = req.query;

  try {
    //verifica si el token existe y si expiro.
    const [rows] = await db.promise().query(
      'SELECT * FROM password_resets WHERE token = ? AND expires > NOW()',
      [token]
    );
    
    //muestra formulario de reset
    res.sendFile(__dirname + '/reset-password.html');
  } catch (err) {
    console.error('Error en servidor:', err);
    res.status(500).send('Error al procesar solicitud');
  }
}); 

// ENPOINT DE BOTON DE CAMBIAR CONTRASEÑA
app.post('/api/reset-password', async (req, res) => {
  const { token, newPassword } = req.body;

  if (!token || !newPassword) {
    return res.status(400).json({
      success: false,
      message: 'Faltan datos para cambiar la contraseña'
    });
  }

  try {
    const [rows] = await db.promise().query(
      'SELECT email FROM password_resets WHERE token = ? AND expires > NOW()',
      [token]
    );

    if (rows.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'El enlace es inválido o expiró'
      });
    }

    const hashedPassword = await bcrypt.hash(newPassword, 8);

    await db.promise().query(
      'UPDATE usuarios SET pass = ? WHERE email = ?',
      [hashedPassword, rows[0].email]
    );

    await db.promise().query(
      'DELETE FROM password_resets WHERE token = ?',
      [token]
    );

    res.json({ success: true, message: 'Contraseña cambiada correctamente' });
  } catch (err) {
    console.error('Error al cambiar la contraseña:', err);
    res.status(500).json({
      success: false,
      message: 'Error interno al cambiar la contraseña'
    });
  }
});

// -------------------- MÓDULO LOGIN --------------------
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, message: 'Complete todos los campos' });
  }

  const sql = 'SELECT id, nombre, usuario, rol, pass FROM usuarios WHERE usuario = ?';
  db.query(sql, [username], (err, rows) => {
    if (err) {
      console.error('Error en /api/login (query):', err);
      return res.status(500).json({ success: false, message: 'Error en el servidor' });
    }

    const ip = (req.headers['x-forwarded-for'] || req.connection.remoteAddress || '').toString();

    if (rows.length > 0) {
      const user = rows[0];
      const passwordIsValid = bcrypt.compareSync(password, user.pass);

      if (passwordIsValid) {
        const ins = 'INSERT INTO login_history (usuario, usuario_id, exito, ip) VALUES (?, ?, ?, ?)';
        db.query(ins, [username, user.id, 1, ip], (e) => {
          if (e) console.error('Error registrando login exitoso:', e);
          const { pass, ...userWithoutPass } = user; // No enviar el hash de la contraseña al frontend
          return res.json({ success: true, message: 'Login exitoso ✅', user: userWithoutPass });
        });
      } else {
        const ins = 'INSERT INTO login_history (usuario, usuario_id, exito, ip) VALUES (?, ?, ?, ?)';
        db.query(ins, [username, user.id, 0, ip], (e) => {
          if (e) console.error('Error registrando login fallido:', e);
          return res.json({ success: false, message: 'Usuario o contraseña incorrectos ❌' });
        });
      }
    } else {
      const ins = 'INSERT INTO login_history (usuario, exito, ip) VALUES (?, ?, ?)';
      db.query(ins, [username, 0, ip], (e) => {
        if (e) console.error('Error registrando login fallido (usuario no encontrado):', e);
        return res.json({ success: false, message: 'Usuario o contraseña incorrectos ❌' });
      });
    }
  });
});

// -------------------- MÓDULO REGISTRO DE USUARIOS --------------------
app.post('/api/register', (req, res) => {
  const { nombre, username, password, email } = req.body;
  if (!nombre || !username || !password || !email) {
    return res.status(400).json({ success: false, message: 'Complete todos los campos' });
  }

  // Verificar si el usuario ya existe
  const checkSql = 'SELECT id FROM usuarios WHERE usuario = ?';
  db.query(checkSql, [username], (err, rows) => {
    if (err) {
      console.error('Error en /api/register (check):', err);
      return res.status(500).json({ success: false, message: 'Error en el servidor' });
    }

    if (rows.length > 0) {
      return res.status(400).json({ success: false, message: 'El usuario ya existe' });
    }

    // Hashear la contraseña antes de guardarla
    const hashedPassword = bcrypt.hashSync(password, 8);

    // Insertar nuevo usuario con la contraseña hasheada
    const insertSql = 'INSERT INTO usuarios (nombre, usuario, pass, email) VALUES (?, ?, ?, ?)';
    db.query(insertSql, [nombre, username, hashedPassword, email], (err2, result) => {
      if (err2) {
        console.error('Error en /api/register (insert):', err2);
        return res.status(500).json({ success: false, message: 'Error al crear el usuario' });
      }

      res.json({ success: true, message: 'Usuario creado correctamente ✅', userId: result.insertId });
    });
  });
});

// -------------------- MÓDULO PRODUCTOS --------------------

// Listar productos
app.get('/api/productos', (req, res) => {
  // Permitir filtrar por categoria: /api/productos?categoria=Bebidas
  const filtroCategoria = req.query.categoria;
  let sql = 'SELECT id, nombre, descripcion, categoria, precio, stock FROM productos';
  const params = [];
  if (filtroCategoria) {
    sql += ' WHERE categoria = ?';
    params.push(filtroCategoria);
  }
  sql += ' ORDER BY nombre ASC';

  db.query(sql, params, (err, rows) => {
    if (err) {
      console.error('Error en /api/productos:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener productos' });
    }
    res.json(rows);
  });
});

// Reporte de productos con bajo stock
app.get('/api/productos/bajo-stock', (req, res) => {
  // Permitir recibir un umbral como query param: /api/productos/bajo-stock?umbral=5
  const umbral = parseInt(req.query.umbral, 10) || 10;
  const sql = 'SELECT id, nombre, precio, stock FROM productos WHERE stock < ? ORDER BY stock ASC';

  db.query(sql, [umbral], (err, rows) => {
    if (err) {
      console.error('Error en /api/productos/bajo-stock:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener el reporte de stock' });
    }
    res.json(rows);
  });
});

// Buscar un producto por ID
app.get('/api/productos/:id', (req, res) => {
  const { id } = req.params; // Capturar el ID que viene en la URL

  const sql = 'SELECT nombre, descripcion, precio, stock FROM productos WHERE id = ?';

  db.query(sql, [id], (err, rows) => {
    if (err) {
      console.error('Error en /api/productos/:id:', err);
      return res.status(500).json({ success: false, message: 'Error al buscar el producto' });
    }

    if (rows.length > 0) {
      // Si se encuentra el producto, lo devolvemos
      res.json({ success: true, producto: rows[0] });
    } else {
      // Si no, devolvemos un error 404
      res.status(404).json({ success: false, message: 'Producto no encontrado' });
    }
  });
});

// Agregar producto
app.post('/api/productos', (req, res) => {
  const { nombre, descripcion, precio, stock, categoria } = req.body;
  if (!nombre || precio == null) {
    return res.status(400).json({ success: false, message: 'Faltan datos del producto' });
  }

  const sql = 'INSERT INTO productos (nombre, descripcion, categoria, precio, stock) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [nombre, descripcion || '', categoria || null, parseFloat(precio), parseInt(stock || 0)], (err, result) => {
    if (err) {
      console.error('Error en /api/productos (insert):', err);
      return res.status(500).json({ success: false, message: 'Error al crear producto' });
    }

    res.json({ success: true, message: 'Producto creado correctamente 🎉', id: result.insertId });
  });
});

// Eliminar producto (ruta a nivel superior)
app.delete('/api/productos/:id', (req, res) => {
  const { id } = req.params;
  if (!id) return res.status(400).json({ success: false, message: 'ID inválido' });

  const sql = 'DELETE FROM productos WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error eliminando producto:', err);
      return res.status(500).json({ success: false, message: 'Error al eliminar producto' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ success: false, message: 'Producto no encontrado' });
    }

    res.json({ success: true, message: 'Producto eliminado correctamente' });
  });
});
// Listar todas las ventas (Historial) con filtros opcionales por fecha (?desde=YYYY-MM-DD&hasta=YYYY-MM-DD)
app.get('/api/ventas', (req, res) => {
  const { desde, hasta } = req.query;
  console.log(`[LOG] Petición a /api/ventas recibida con filtros: desde=${desde}, hasta=${hasta}`); // LOG

  let sql = `
    SELECT v.id, v.fecha, v.total, u.nombre as usuario_nombre 
    FROM ventas v
    LEFT JOIN usuarios u ON v.usuario_id = u.id`;

  const params = [];
  const conds = [];
  // Comparar solo la parte de fecha para evitar problemas de horas o tipos DATE/DATETIME
  if (desde) { conds.push('DATE(v.fecha) >= ?'); params.push(desde); }
  if (hasta) { conds.push('DATE(v.fecha) <= ?'); params.push(hasta); }
  if (conds.length) sql += ' WHERE ' + conds.join(' AND ');
  sql += ' ORDER BY v.fecha DESC';

  console.log(`[LOG] SQL generado: ${sql}`); // LOG
  console.log(`[LOG] Parámetros: ${JSON.stringify(params)}`); // LOG

  db.query(sql, params, (err, rows) => {
    if (err) {
      console.error('Error en GET /api/ventas:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener el historial de ventas' });
    }
    console.log(`[LOG] Filas devueltas: ${rows.length}`); // LOG
    res.json(rows);
  });
});
// Historial de logueo con filtros opcionales por fecha (?desde=YYYY-MM-DD&hasta=YYYY-MM-DD)
app.get('/api/login-history', (req, res) => {
  const { desde, hasta } = req.query;
  let sql = `
    SELECT lh.id, lh.fecha, lh.usuario, lh.usuario_id, lh.exito, lh.ip, u.nombre as usuario_nombre
    FROM login_history lh
    LEFT JOIN usuarios u ON lh.usuario_id = u.id`;

  const params = [];
  const conds = [];
  if (desde) { conds.push('lh.fecha >= ?'); params.push(`${desde} 00:00:00`); }
  if (hasta) { conds.push('lh.fecha <= ?'); params.push(`${hasta} 23:59:59`); }
  if (conds.length) sql += ' WHERE ' + conds.join(' AND ');
  sql += ' ORDER BY lh.fecha DESC';

  db.query(sql, params, (err, rows) => {
    if (err) {
      console.error('Error en GET /api/login-history:', err);
      return res.status(500).json({ success: false, message: 'Error al obtener el historial de logueo' });
    }
    res.json(rows);
  });
});

// -------------------- MÓDULO VENTAS --------------------
app.post('/api/ventas', (req, res) => {
  const { items, usuario_id } = req.body;
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ success: false, message: 'No hay ítems en la venta' });
  }

  let index = 0;
  let total = 0.0;

  function checkNext() {
    if (index >= items.length) {
      const insertVentaSql = 'INSERT INTO ventas (total, usuario_id) VALUES (?, ?)';
      db.query(insertVentaSql, [total, usuario_id || null], (errV, resultV) => {
        if (errV) {
          console.error('Error insertando venta:', errV);
          return res.status(500).json({ success: false, message: 'Error al registrar la venta' });
        }

        const ventaId = resultV.insertId;
        insertDetail(0, ventaId);
      });
      return;
    }

    const it = items[index];
    const sqlProd = 'SELECT id, stock, precio FROM productos WHERE id = ?';
    db.query(sqlProd, [it.producto_id], (errP, rowsP) => {
      if (errP) {
        console.error('Error consultando producto:', errP);
        return res.status(500).json({ success: false, message: 'Error al verificar productos' });
      }

      if (!rowsP || rowsP.length === 0) {
        return res.status(400).json({ success: false, message: `Producto ${it.producto_id} no existe` });
      }

      const stockDisponible = rowsP[0].stock;
      if (stockDisponible < it.cantidad) {
        return res.status(400).json({ success: false, message: `Stock insuficiente para producto ${it.producto_id}` });
      }

      const precioUnit = (it.precio_unitario != null) ? Number(it.precio_unitario) : parseFloat(rowsP[0].precio);
      total += precioUnit * Number(it.cantidad);

      index++;
      checkNext();
    });
  }

  function insertDetail(idx, ventaId) {
    if (idx >= items.length) {
      return res.json({ success: true, message: 'Venta registrada correctamente 🧾', ventaId, total });
    }

    const it = items[idx];
    const insertDetSql = 'INSERT INTO detalle_venta (venta_id, producto_id, cantidad, precio_unitario) VALUES (?, ?, ?, ?)';
    db.query(insertDetSql, [ventaId, it.producto_id, it.cantidad, it.precio_unitario], (errD) => {
      if (errD) {
        console.error('Error insertando detalle:', errD);
        return res.status(500).json({ success: false, message: 'Error al registrar detalle de venta' });
      }

      const updateStockSql = 'UPDATE productos SET stock = stock - ? WHERE id = ?';
      db.query(updateStockSql, [it.cantidad, it.producto_id], (errU) => {
        if (errU) {
          console.error('Error actualizando stock:', errU);
          return res.status(500).json({ success: false, message: 'Error al actualizar stock' });
        }

        insertDetail(idx + 1, ventaId);
      });
    });
  }

  checkNext();
});

// -------------------- MÓDULO CAJA --------------------

// Apertura
app.post('/api/caja/apertura', (req, res) => {
  const { apertura, usuario_id } = req.body;
  if (apertura == null) {
    return res.status(400).json({ success: false, message: 'Falta monto de apertura' });
  }

  const sql = 'INSERT INTO caja (fecha, apertura, usuario_id) VALUES (CURDATE(), ?, ?)';
  db.query(sql, [parseFloat(apertura), usuario_id || null], (err, result) => {
    if (err) {
      console.error('Error en /api/caja/apertura:', err);
      return res.status(500).json({ success: false, message: 'Error al abrir caja' });
    }

    res.json({ success: true, message: 'Caja abierta correctamente 💵', cajaId: result.insertId });
  });
});

// Movimiento
app.post('/api/caja/movimiento', (req, res) => {
  const { caja_id, descripcion, monto, tipo } = req.body;
  if (!caja_id || monto == null || !['entrada', 'salida'].includes(tipo)) {
    return res.status(400).json({ success: false, message: 'Datos inválidos' });
  }

  const sql = 'INSERT INTO movimientos_caja (caja_id, descripcion, monto, tipo) VALUES (?, ?, ?, ?)';
  db.query(sql, [caja_id, descripcion || '', parseFloat(monto), tipo], (err, result) => {
    if (err) {
      console.error('Error en /api/caja/movimiento:', err);
      return res.status(500).json({ success: false, message: 'Error al insertar movimiento' });
    }

    res.json({ success: true, message: 'Movimiento registrado ✅', movimientoId: result.insertId });
  });
});

// Cierre
app.post('/api/caja/cierre', (req, res) => {
  const { caja_id, cierre } = req.body;
  if (!caja_id || cierre == null) {
    return res.status(400).json({ success: false, message: 'Faltan datos para cierre' });
  }

  const sqlA = 'SELECT apertura FROM caja WHERE id = ?';
  db.query(sqlA, [caja_id], (errA, rowsA) => {
    if (errA) {
      console.error('Error en /api/caja/cierre (apertura):', errA);
      return res.status(500).json({ success: false, message: 'Error al consultar caja' });
    }

    if (!rowsA || rowsA.length === 0) {
      return res.status(400).json({ success: false, message: 'Caja no encontrada' });
    }

    const apertura = parseFloat(rowsA[0].apertura);

    const sqlMov = 'SELECT tipo, SUM(monto) as total FROM movimientos_caja WHERE caja_id = ? GROUP BY tipo';
    db.query(sqlMov, [caja_id], (errM, rowsM) => {
      if (errM) {
        console.error('Error en /api/caja/cierre (mov):', errM);
        return res.status(500).json({ success: false, message: 'Error al consultar movimientos' });
      }

      let entradas = 0, salidas = 0;
      for (const r of rowsM) {
        if (r.tipo === 'entrada') entradas = parseFloat(r.total);
        if (r.tipo === 'salida') salidas = parseFloat(r.total);
      }

      const esperado = apertura + entradas - salidas;
      const diferencia = parseFloat(cierre) - esperado;

      const updateSql = 'UPDATE caja SET cierre = ? WHERE id = ?';
      db.query(updateSql, [parseFloat(cierre), caja_id], (errU) => {
        if (errU) {
          console.error('Error actualizando cierre:', errU);
          return res.status(500).json({ success: false, message: 'Error al cerrar caja' });
        }

        res.json({ success: true, apertura, entradas, salidas, esperado, cierre: parseFloat(cierre), diferencia });
      });
    });
  });
});

// Listar movimientos
app.get('/api/caja/movimientos', (req, res) => {
  const sql = `SELECT mc.*, c.fecha as caja_fecha
               FROM movimientos_caja mc
               LEFT JOIN caja c ON mc.caja_id = c.id
               ORDER BY mc.fecha DESC`;

  db.query(sql, (err, rows) => {
    if (err) {
      console.error('Error en /api/caja/movimientos:', err);
      return res.status(500).json({ success: false, message: 'Error al listar movimientos' });
    }

    res.json(rows);
  });
});

// -------------------- INICIO DEL SERVIDOR --------------------
app.listen(port, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${port}`);
});
