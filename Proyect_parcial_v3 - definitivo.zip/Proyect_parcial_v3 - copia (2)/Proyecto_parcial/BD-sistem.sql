create database negocio_db1;
use negocio_db1;

-- Tabla contraseñaReset
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires DATETIME NOT NULL
);

-- Tabla de usuarios 
CREATE TABLE usuarios ( 
    id INT AUTO_INCREMENT PRIMARY KEY, 
    nombre VARCHAR(50) NOT NULL, 
    usuario VARCHAR(30) UNIQUE NOT NULL, 
    email VARCHAR(100) UNIQUE NOT NULL,
    pass VARCHAR(255) NOT NULL, -- en backend se guarda hasheada 
    rol ENUM('admin', 'vendedor', 'cajero') DEFAULT 'admin' 
); 
 -- Tabla de productos 
CREATE TABLE productos ( 
    id INT AUTO_INCREMENT PRIMARY KEY, 
    nombre VARCHAR(150) NOT NULL, 
    descripcion VARCHAR(255), 
    categoria VARCHAR(150) NOT NULL, 
    precio DECIMAL(10,2) NOT NULL, 
    stock INT DEFAULT 0, 
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP 
); 
 -- Tabla de ventas 
CREATE TABLE ventas ( 
    id INT AUTO_INCREMENT PRIMARY KEY, 
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    total DECIMAL(10,2) NOT NULL, 
    usuario_id INT, 
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) 
);
 -- Detalle de cada venta (productos vendidos) 
CREATE TABLE detalle_venta ( 
    id INT AUTO_INCREMENT PRIMARY KEY,
	venta_id INT, 
    producto_id INT, 
    cantidad INT NOT NULL, 
    precio_unitario DECIMAL(10,2) NOT NULL, 
    FOREIGN KEY (venta_id) REFERENCES ventas(id), 
    FOREIGN KEY (producto_id) REFERENCES productos(id) 
); 
 -- Tabla de caja 
CREATE TABLE caja ( 
    id INT AUTO_INCREMENT PRIMARY KEY, 
    fecha DATETIME NOT NULL, 
    apertura DECIMAL(10,2) NOT NULL, 
    cierre DECIMAL(10,2), 
    usuario_id INT, 
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) 
); 
 -- Movimientos de caja 
CREATE TABLE movimientos_caja ( 
    id INT AUTO_INCREMENT PRIMARY KEY, 
    caja_id INT, 
    descripcion VARCHAR(255), 
    monto DECIMAL(10,2) NOT NULL, 
    tipo ENUM('entrada','salida') NOT NULL, 
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    FOREIGN KEY (caja_id) REFERENCES caja(id) 
); 
CREATE TABLE login_history (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  fecha DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuario VARCHAR(100) NOT NULL,
  usuario_id BIGINT NULL,
  exito TINYINT(1) NOT NULL, -- 1=exitoso, 0=fallido
  ip VARCHAR(45) NULL
);
ALTER TABLE login_history ADD CONSTRAINT fk_login_user FOREIGN KEY (usuario_id) REFERENCES usuarios(id);
INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
-- BEBIDAS CON ALCOHOL 
('Cerveza Stella Artois 330 ml', 'Cerveza importada', 'Bebidas con alcohol', 3000, 50, NOW()),
('Cerveza Brahma 1 L', 'Cerveza rubia', 'Bebidas con alcohol', 2600 * 1.2, 40, NOW()),  
('Absolut Vodka 750ml', 'Vodka premium', 'Bebidas con alcohol', 18000 * 1.2, 10, NOW()),  
('Smirnoff Vodka 750ml', 'Vodka importado', 'Bebidas con alcohol', 7200 * 1.2, 10, NOW()),  
('Cerveza Quilmes 1 L', 'Cerveza rubia', 'Bebidas con alcohol', 3500 * 1.2, 40, NOW()),  
('Cerveza Patagonia Amber 500 ml', 'Cerveza artesanal', 'Bebidas con alcohol', 1600 * 1.2, 50, NOW()),  
('Vino Malbec Trapiche 750 ml', 'Vino tinto Malbec', 'Bebidas con alcohol', 10200 * 1.2, 50, NOW()),  
('Gancia 750 ml', 'Aperitivo', 'Bebidas con alcohol', 2200 * 1.2, 50, NOW()),  
('Vermut Cinzano 750 ml', 'Vermut clásico', 'Bebidas con alcohol', 1800 * 1.2, 50, NOW()),
('Cerveza Andes IPA 1L', 'Cerveza IPA', 'Bebidas con alcohol', 4000, 20, NOW()),
('Cerveza Budweiser 355 ml', 'Cerveza rubia importada', 'Bebidas con alcohol', 800, 50, NOW()),
('Cerveza Brahma 500 ml', 'Cerveza rubia', 'Bebidas con alcohol', 600, 50, NOW()),
('Cerveza Corona 355 ml', 'Cerveza rubia importada', 'Bebidas con alcohol', 850, 50, NOW()),
('Cerveza Heineken 500 ml', 'Cerveza rubia importada', 'Bebidas con alcohol', 900, 50, NOW()),
('Cerveza Patagonia Amber 500 ml', 'Cerveza artesanal', 'Bebidas con alcohol', 1100, 50, NOW()),
('Cerveza Quilmes 500 ml', 'Cerveza rubia', 'Bebidas con alcohol', 650, 50, NOW()),
('Cerveza Schneider 500 ml', 'Cerveza rubia', 'Bebidas con alcohol', 550, 50, NOW()),
('Cerveza Schneider Stout 500 ml', 'Cerveza negra', 'Bebidas con alcohol', 650, 50, NOW()),
('Cerveza Stella 1L', 'Cerveza premium', 'Bebidas con alcohol', 5000, 20, NOW()),
('Cerveza Stella Artois 500 ml', 'Cerveza importada', 'Bebidas con alcohol', 1000, 50, NOW()),
('Fernet Branca 750ml', 'Aperitivo', 'Bebidas con alcohol', 12000, 18, NOW()),
('Smirnoff Vodka 750ml', 'Vodka importado', 'Bebidas con alcohol', 15000, 10, NOW()),
('Vino Norton Malbec 750ml', 'Vino fino', 'Bebidas con alcohol', 7000, 15, NOW()),
('Vino Toro Tinto 1L', 'Vino de mesa', 'Bebidas con alcohol', 2500, 30, NOW()),
('Vino Malbec Trapiche 750 ml', 'Vino tinto Malbec', 'Bebidas con alcohol', 1500, 50, NOW()),
('Vino Cabernet Sauvignon Norton 750 ml', 'Vino tinto Cabernet', 'Bebidas con alcohol', 1600, 50, NOW()),
('Vino Torrontés La Riojana 750 ml', 'Vino blanco Torrontés', 'Bebidas con alcohol', 1400, 50, NOW()),
('Sidra Real 1 L', 'Sidra clásica', 'Bebidas con alcohol', 700, 50, NOW()),
-- BEBIDAS SIN ALCOHOL
('Ades Vainilla 1L', 'Bebida vegetal', 'Bebidas sin alcohol', 3000, 20, NOW()),
('Aquarius Manzana', 'Bebida hidratante', 'Bebidas sin alcohol', 2200, 30, NOW()),
('Aquarius Pera', 'Bebida hidratante', 'Bebidas sin alcohol', 2200, 30, NOW()),
('Bon Aqua 2L', 'Agua mineral', 'Bebidas sin alcohol', 1400, 50, NOW()),
('Cepita Durazno 1L', 'Jugo durazno', 'Bebidas sin alcohol', 3000, 20, NOW()),
('Cepita Naranja 1L', 'Jugo naranja', 'Bebidas sin alcohol', 3000, 20, NOW()),
('Coca Cola 1.5L', 'Gaseosa cola', 'Bebidas sin alcohol', 2800, 40, NOW()),
('Coca-Cola 500 ml', 'Gaseosa cola', 'Bebidas sin alcohol', 800, 50, NOW()),
('Coca Cola Zero 1.5L', 'Gaseosa sin azúcar', 'Bebidas sin alcohol', 2800, 40, NOW()),
('Gatorade Citrus 500ml', 'Bebida deportiva', 'Bebidas sin alcohol', 1800, 25, NOW()),
('Gatorade Manzana 500ml', 'Bebida deportiva', 'Bebidas sin alcohol', 1800, 25, NOW()),
('Monster Energy 473ml', 'Energética', 'Bebidas sin alcohol', 3800, 15, NOW()),
('Speed 473ml', 'Energética', 'Bebidas sin alcohol', 1600, 50, NOW()),
('Té frío Nestea 500 ml', 'Té sabor limón', 'Bebidas sin alcohol', 370, 50, NOW()),
('Villavicencio 1.5L', 'Agua mineral', 'Bebidas sin alcohol', 1100, 40, NOW()),
('Vitamin Water Power C 500ml', 'Bebida funcional', 'Bebidas sin alcohol', 2500, 20, NOW()),
('Agua sabor frutilla Levité 500 ml', 'Agua saborizada', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Agua sabor manzana Levité 500 ml', 'Agua saborizada', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Agua saborizada Levité 500 ml', 'Agua saborizada', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Agua con gas Eco de los Andes 500 ml', 'Agua con gas', 'Bebidas sin alcohol', 1100, 50, NOW()),
('Agua tónica Schweppes 500 ml', 'Agua tónica', 'Bebidas sin alcohol', 1800, 50, NOW()),
('Gaseosa Manaos 500 ml', 'Gaseosa cola', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Gaseosa Paso de los Toros 500 ml', 'Gaseosa cola', 'Bebidas sin alcohol', 1800, 50, NOW()),
('Gaseosa Coca-Cola Zero 500 ml', 'Gaseosa cola sin azúcar', 'Bebidas sin alcohol', 850, 50, NOW()),
('Gaseosa Sprite Zero 500 ml', 'Gaseosa limón sin azúcar', 'Bebidas sin alcohol', 850, 50, NOW()),
('Jugo de durazno 500 ml', 'Jugo natural', 'Bebidas sin alcohol', 650, 50, NOW()),
('Jugo de naranja exprimido 500 ml', 'Jugo natural', 'Bebidas sin alcohol', 650, 50, NOW()),
('Jugo en caja Cepita 200 ml', 'Jugo en caja', 'Bebidas sin alcohol', 1500, 50, NOW()),
('Jugo en caja Cunning 200 ml', 'Jugo en caja', 'Bebidas sin alcohol', 1500, 50, NOW()),
('Pepsi 1.5L', 'Gaseosa cola', 'Bebidas sin alcohol', 2600, 40, NOW()),
('Pepsi 500 ml', 'Gaseosa cola', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Sprite 1.5L', 'Gaseosa lima-limón', 'Bebidas sin alcohol', 2600, 35, NOW()),
('Sprite 500 ml', 'Gaseosa limón', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Fanta 1.5L', 'Gaseosa naranja', 'Bebidas sin alcohol', 2600, 35, NOW()),
('Fanta 500 ml', 'Gaseosa naranja', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Manaos Cola 2.25L', 'Gaseosa cola económica', 'Bebidas sin alcohol', 2300, 50, NOW()),
('Manaos Naranja 2.25L', 'Gaseosa naranja económica', 'Bebidas sin alcohol', 2300, 50, NOW()),
('Bon Aqua 2L', 'Agua mineral', 'Bebidas sin alcohol', 1200, 50, NOW()),
('Villavicencio 1.5L', 'Agua mineral', 'Bebidas sin alcohol', 1100, 40, NOW());
-- GOLOSINAS
INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
('Alfajor Guaymallén', 'Alfajor económico', 'Golosinas', 750, 100, NOW()),
('Alfajor Jorgito 55 g', 'Alfajor de dulce de leche', 'Golosinas', 900, 80, NOW()),
('Alfajor Milka Oreo 61g', 'Alfajor premium', 'Golosinas', 2000, 30, NOW()),
('Beldent Frutilla 20 g', 'Chicle frutilla', 'Golosinas', 800, 50, NOW()),
('Beldent Menta 20 g', 'Chicle menta', 'Golosinas', 800, 50, NOW()),
('Block Maní 90 g', 'Chocolate con maní', 'Golosinas', 1000, 30, NOW()),
('Bon o Bon', 'Bombón relleno', 'Golosinas', 350, 50, NOW()),
('Bon o Bon x6', 'Bombones paquete 6', 'Golosinas', 1200, 20, NOW()),
('Butter Toffees', 'Caramelos', 'Golosinas', 550, 50, NOW()),
('Caramelos Media Hora', 'Caramelos duros', 'Golosinas', 150, 80, NOW()),
('Chicles Clorets', 'Chicles menta', 'Golosinas', 200, 50, NOW()),
('Chicles Stimorol', 'Chicles frutales', 'Golosinas', 200, 50, NOW()),
('Chocolate Cofler 90 g', 'Chocolate clásico', 'Golosinas', 800, 30, NOW()),
('Chocolate Milka con leche 55 g', 'Chocolate con leche', 'Golosinas', 1500, 30, NOW()),
('Chocolate Shot 35 g', 'Tableta con maní', 'Golosinas', 900, 40, NOW()),
('Chocolates Bon o Bon Negro', 'Bombón chocolate amargo', 'Golosinas', 800, 50, NOW()),
('Chocolates Cachafaz', 'Chocolate relleno', 'Golosinas', 600, 50, NOW()),
('Chocolates Jorgito', 'Chocolate relleno', 'Golosinas', 600, 50, NOW()),
('Chocolates Milka Oreo', 'Chocolate relleno', 'Golosinas', 800, 50, NOW()),
('Chocolates Surtidos Arcor', 'Bombones surtidos', 'Golosinas', 600, 50, NOW()),
('Chocolinas', 'Galletitas de chocolate', 'Golosinas', 900, 40, NOW()),
('Confites Happys', 'Confites de chocolate', 'Golosinas', 550, 50, NOW()),
('M&M Maní 90 g', 'Golosina de chocolate', 'Golosinas', 900, 30, NOW()),
('Mantecol', 'Dulce de maní', 'Golosinas', 500, 50, NOW()),
('Milka Chocolate con leche', 'Chocolate con leche', 'Golosinas', 700, 50, NOW()),
('Palitos de la Selva 50 g', 'Caramelos masticables', 'Golosinas', 300, 80, NOW()),
('Pico Dulce chupetín', 'Chupetín tradicional', 'Golosinas', 200, 100, NOW()),
('Rocklets 90 g', 'Chocolate confitado', 'Golosinas', 800, 40, NOW()),
('Sugus Max 50 g', 'Caramelos', 'Golosinas', 300, 60, NOW()),
('Sugus', 'Caramelos masticables', 'Golosinas', 200, 50, NOW()),
('Trident', 'Chicles', 'Golosinas', 150, 50, NOW());
-- SÁNGUCHES DE MIGA
INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
('Sánguche de miga atún 3 unidades', 'Atún', 'Sánguches de miga', 1800, 20, NOW()),
('Sánguche de miga jamón cocido 3 unidades', 'Jamón cocido', 'Sánguches de miga', 1700, 20, NOW()),
('Sánguche de miga jamón crudo 3 unidades', 'Jamón crudo', 'Sánguches de miga', 2000, 20, NOW()),
('Sánguche de miga jamón y queso 3 unidades', 'Jamón y queso', 'Sánguches de miga', 1800, 20, NOW()),
('Sánguche de miga pollo y lechuga 3 unidades', 'Pollo y lechuga', 'Sánguches de miga', 1800, 20, NOW()),
('Sánguche de miga queso y tomate 3 unidades', 'Queso y tomate', 'Sánguches de miga', 1700, 20, NOW()),
('Sánguche de miga lechuga, tomate y pollo 3 unidades', 'pollo y verdura', 'Sánguches de miga', 2000, 20, NOW());
------------------------------------------------------------------------------

-- SNACKS
INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
('Chips de banana 100 g', 'Chips dulces', 'Snacks', 800, 50, NOW()),
('Chips de camote 100 g', 'Chips dulces', 'Snacks', 850, 50, NOW()),
('Doritos 140 g', 'Snack de maíz', 'Snacks', 1200, 50, NOW()),
('Maní confitado 100 g', 'Maní dulce', 'Snacks', 700, 50, NOW()),
('Maní japonés 100 g', 'Maní recubierto', 'Snacks', 650, 50, NOW()),
('Maní salado 100 g', 'Maní tostado salado', 'Snacks', 600, 50, NOW()),
('Mix frutos secos 150 g', 'Nueces y almendras', 'Snacks', 1500, 50, NOW()),
('Nachos con queso 150 g', 'Snack de maíz con queso', 'Snacks', 1200, 50, NOW()),
('Palitos de queso 100 g', 'Snack salado', 'Snacks', 650, 50, NOW()),
('Palitos con chocolate 120 g', 'Snack dulce', 'Snacks', 700, 50, NOW()),
('Palitos salados 120 g', 'Snack salado', 'Snacks', 550, 50, NOW()),
('Papas fritas Lays 150 g', 'Papas fritas clásicas', 'Snacks', 1000, 50, NOW()),
('Papas fritas Pringles 165 g', 'Papas fritas en tubo', 'Snacks', 1300, 50, NOW()),
('Papas fritas Ruffles 150 g', 'Papas onduladas', 'Snacks', 1100, 50, NOW()),
('Papas onduladas 150 g', 'Papas fritas clásicas', 'Snacks', 1000, 50, NOW()),
('Pretzels 100 g', 'Snack salado', 'Snacks', 600, 50, NOW()),
('Snack mix 150 g', 'Mezcla de frutos secos y semillas', 'Snacks', 1100, 50, NOW()),
('Galletitas de arroz 100 g', 'Galletitas ligeras', 'Snacks', 450, 50, NOW());

-- LÁCTEOS
INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
('Galletitas surtidas 200 g', 'Galletitas dulces', 'Snacks', 700, 50, NOW()),
('Crema de leche 200 ml', 'Crema para cocinar', 'Lácteos', 600, 50, NOW()),
('Leche chocolatada 200 ml', 'Bebida láctea sabor chocolate', 'Lácteos', 450, 50, NOW()),
('Leche descremada 1L', 'Leche baja en grasa', 'Lácteos', 950, 50, NOW()),
('Leche entera 1L', 'Leche fresca', 'Lácteos', 900, 50, NOW()),
('Manteca 200 g', 'Manteca tradicional', 'Lácteos', 1000, 50, NOW()),
('Postres lácteos 120 g', 'Postre de leche', 'Lácteos', 350, 50, NOW()),
('Queso barra 250 g', 'Queso en barra', 'Lácteos', 1500, 50, NOW()),
('Queso crema 200 g', 'Queso untable', 'Lácteos', 1200, 50, NOW()),
('Queso de máquina 200 g', 'Queso procesado', 'Lácteos', 1100, 50, NOW()),
('Queso fresco 250 g', 'Queso fresco típico', 'Lácteos', 1200, 50, NOW()),
('Queso port salut 250 g', 'Queso suave', 'Lácteos', 1500, 50, NOW()),
('Queso rallado 100 g', 'Queso rallado para cocinar', 'Lácteos', 800, 50, NOW()),
('Queso sardo 250 g', 'Queso curado', 'Lácteos', 1800, 50, NOW()),
('Queso tybo 250 g', 'Queso semiduro', 'Lácteos', 1500, 50, NOW()),
('Queso untable light 200 g', 'Queso untable bajo en grasa', 'Lácteos', 1100, 50, NOW()),
('Ricota 250 g', 'Queso ricota fresco', 'Lácteos', 900, 50, NOW()),
('Yogur bebible 200 ml', 'Yogur líquido', 'Lácteos', 400, 50, NOW()),
('Yogur con frutas 200 g', 'Yogur frutado', 'Lácteos', 600, 50, NOW()),
('Yogur griego 150 g', 'Yogur espeso', 'Lácteos', 600, 50, NOW()),
('Yogur natural 200 g', 'Yogur sin sabor', 'Lácteos', 500, 50, NOW());

-- HELADOS
INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
('Helado alfajor 1L', 'Helado sabor alfajor', 'Helados', 4800, 30, NOW()),
('Helado brownie 1L', 'Helado sabor brownie', 'Helados', 5000, 30, NOW()),
('Helado brownie chocolate 1L', 'Helado sabor brownie y chocolate', 'Helados', 5000, 30, NOW()),
('Helado cheesecake 1L', 'Helado sabor cheesecake', 'Helados', 4800, 30, NOW()),
('Helado crema americana 1L', 'Helado sabor crema', 'Helados', 4000, 30, NOW()),
('Helado dulce de leche 1L', 'Helado sabor dulce de leche', 'Helados', 4500, 30, NOW()),
('Helado dulce de leche granizado 1L', 'Helado sabor dulce de leche con trozos', 'Helados', 4500, 30, NOW()),
('Helado frutilla 1L', 'Helado sabor frutilla', 'Helados', 4000, 30, NOW()),
('Helado limón 1L', 'Helado sabor limón', 'Helados', 3500, 30, NOW()),
('Helado menta granizada 1L', 'Helado sabor menta con chocolate', 'Helados', 4000, 30, NOW()),
('Helado maracuyá 1L', 'Helado sabor maracuyá', 'Helados', 4000, 30, NOW()),
('Helado napolitano 1L', 'Helado sabor chocolate, vainilla y frutilla', 'Helados', 4500, 30, NOW()),
('Helado praline 1L', 'Helado sabor praliné', 'Helados', 4800, 30, NOW()),
('Helado trio chocolate vainilla frutilla 1L', 'Helado mixto', 'Helados', 4500, 30, NOW()),
('Helado vainilla 1L', 'Helado sabor vainilla', 'Helados', 3500, 30, NOW()),
('Helado cheesecake 1L', 'Helado sabor cheesecake', 'Helados', 4800, 30, NOW()),
('Helado cookies & cream 1L', 'Helado sabor cookies & cream', 'Helados', 4800, 30, NOW()),
('Helado banana split 1L', 'Helado con sabores variados', 'Helados', 5000, 30, NOW()),
('Helado brownie chocolate 1L', 'Helado sabor brownie y chocolate', 'Helados', 5000, 30, NOW());

INSERT INTO productos (nombre, descripcion, categoria, precio, stock, creado_en) VALUES
('Marlboro Red KS 20', 'Cigarrillo Marlboro común 20 unidades', 'Cigarrillos', 4700, 50, NOW()), 
('Marlboro Crafted Red KS 20', 'Marlboro Crafted rojo 20 unidades', 'Cigarrillos', 2600, 50, NOW()), 
('Philip Morris Red KS 20', 'Cigarrillo Philip Morris común 20 unidades', 'Cigarrillos', 4100, 50, NOW()), 
('Chesterfield Red KS 20', 'Cigarrillo Chesterfield rojo 20 unidades', 'Cigarrillos', 3400, 50, NOW()),  
('Lucky Strike Click Cool Box 12', 'Lucky Strike con cápsula 12 unidades', 'Cigarrillos', 2800, 50, NOW()),  
('Golden King Soft Blue 20', 'Golden King Soft azul 20 unidades', 'Cigarrillos', 1900, 50, NOW()),
('Golden King Soft Green 20', 'Golden King Soft verde 20 unidades', 'Cigarrillos', 1800, 50, NOW()),  
('Golden King Soft Red 20', 'Golden King Soft rojo 20 unidades', 'Cigarrillos', 1700, 50, NOW()),  
('Milenio Box 20', 'Milenio marca económica 20 unidades', 'Cigarrillos', 2100, 50, NOW()),
('Milenio Gold 20', 'Milenio Gold 20 unidades', 'Cigarrillos', 2100, 50, NOW()),
('Milenio Menta 20', 'Milenio con sabor menta 20 unidades', 'Cigarrillos', 2100, 50, NOW()),  
('Philip Morris Original KS 12', 'Philip Morris original 12 unidades', 'Cigarrillos', 3100, 50, NOW()),  
('Red Point Blue 20', 'Cigarrillo Red Point azul 20 unidades', 'Cigarrillos', 2100, 50, NOW()),
('Red Point Filter 20', 'Cigarrillo Red Point común 20 unidades', 'Cigarrillos', 2100, 50, NOW()),
('Parliament Super Slims 100’s Box 20', 'Parliament super slim 100s 20 unidades', 'Cigarrillos', 5100, 50, NOW()), 
('Marlboro Red Titanium Box 20', 'Marlboro Box 20 edición Titanium', 'Cigarrillos', 4900, 50, NOW()),
('Marlboro Red Common 20', 'Marlboro común 20 unidades', 'Cigarrillos', 4300, 50, NOW()),
('Chesterfield Blue Motion Box 20', 'Chesterfield azul Motion 20 unidades', 'Cigarrillos', 3500, 50, NOW()),  
('Harmony Dorado/Negro/Colorado 20', 'Harmony cigarrillos económicos 20 unidades', 'Cigarrillos', 3100, 50, NOW()),
('Marlboro Crafted Box 20 Coral/Forward', 'Marlboro Crafted coral o forward 20 unidades', 'Cigarrillos', 2500, 50, NOW());
